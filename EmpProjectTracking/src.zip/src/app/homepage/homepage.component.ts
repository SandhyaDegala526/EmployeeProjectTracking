import { Component} from '@angular/core';


@Component({
  templateUrl: './homepage.component.html'
})
export class HomepageComponent {}
